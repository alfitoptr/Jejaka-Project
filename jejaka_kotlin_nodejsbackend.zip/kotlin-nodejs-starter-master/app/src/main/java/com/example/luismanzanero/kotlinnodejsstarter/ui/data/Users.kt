package com.example.luismanzanero.kotlinnodejsstarter.ui.data

import com.example.luismanzanero.kotlinnodejsstarter.ui.data.Items

data class Users (val total_count: String, val items: MutableList<Items>)