package com.example.luismanzanero.kotlinnodejsstarter.ui.data

data class Owner (val login: String)