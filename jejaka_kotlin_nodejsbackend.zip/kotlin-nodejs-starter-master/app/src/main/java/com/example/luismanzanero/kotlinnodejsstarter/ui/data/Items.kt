package com.example.luismanzanero.kotlinnodejsstarter.ui.data

data class Items (val name: String, val owner: Owner)